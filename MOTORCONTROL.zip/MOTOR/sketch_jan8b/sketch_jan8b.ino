/**********************************************************************
 * MOTOR MONITORING SYSTEM - ARDUINO NANO IoT 33
 * USING 20x4 I2C LCD DISPLAY + LEDS
 **********************************************************************/

#include <WiFiNINA.h>
#include <ArduinoHttpClient.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <EmonLib.h>
#include <OneWire.h>
#include <DallasTemperature.h>

// ============================
// LCD Configuration
// ============================
#define LCD_ADDRESS 0x27  // Common I2C address for 20x4 LCD (could be 0x3F)
#define LCD_COLS 20
#define LCD_ROWS 4
LiquidCrystal_I2C lcd(LCD_ADDRESS, LCD_COLS, LCD_ROWS);

// ============================
// WiFi Configuration
// ============================
char ssid[] = "Keipi";           // Replace with your WiFi SSID
char pass[] = "Rwanda123";     // Replace with your WiFi Password
int wifiStatus = WL_IDLE_STATUS;

// ============================
// Database Configuration - FIXED
// ============================
char server[] = "10.76.139.152";  // ← CHANGE THIS TO YOUR PC'S IP
int port = 80;
String apiEndpoint = "/MOTOR/api.php";

WiFiClient wifiClient;
HttpClient client = HttpClient(wifiClient, server, port);

// ============================
// Energy Monitoring Setup
// ============================
EnergyMonitor emonVoltage;
EnergyMonitor emonCurrent1, emonCurrent2, emonCurrent3;

// Calibration Constants
#define VOLTAGE_CALIBRATION 480.0
#define CURRENT_CALIBRATION 85.0
#define PHASE_SHIFT 1.7

// ============================
// GSM Module Configuration - Using Serial1
// ============================
#define GSM_SERIAL Serial1
#define PHONE_NUMBER "+250788708035"

// ============================
// PIN DEFINITIONS
// ============================
// Sensor Pins
#define TEMP_SENSOR_PIN    5
#define VIBRATION_PIN      4

// Output Pins
#define BUZZER_PIN         3
#define RELAY_PIN          2
#define RED_LED_PIN        6      // Red LED for fault/alarm
#define YELLOW_LED_PIN     7      // Yellow LED for warning/standby
#define GREEN_LED_PIN      8      // Green LED for normal operation

// Button Pins (using digital pins)
#define START_BUTTON_PIN   9      // Digital pin for START button
#define STOP_BUTTON_PIN    10     // Digital pin for STOP button  
#define RESET_BUTTON_PIN   11     // Digital pin for RESET/Page button

// ============================
// System Parameters
// ============================
#define VOLTAGE_MIN        180.0
#define VOLTAGE_MAX        250.0
#define CURRENT_MAX        25.0
#define TEMP_MAX           30.0
#define TEMP_WARNING       25.0   // Temperature warning threshold

// ============================
// Timing & Intervals
// ============================
#define SENSOR_READ_INTERVAL   2000
#define DISPLAY_UPDATE_INTERVAL 1000
#define DATABASE_SEND_INTERVAL  10000
#define WIFI_RETRY_INTERVAL    30000
#define BUTTON_DEBOUNCE        250
#define DISPLAY_SCROLL_INTERVAL 3000  // Time between display page changes
#define LED_BLINK_INTERVAL     500    // LED blinking interval for warnings

// ============================
// Global Variables
// ============================
typedef struct {
  float voltage = 0;
  float currentL1 = 0;
  float currentL2 = 0;
  float currentL3 = 0;
  float temperature = 0;
  int vibration = 0;
  bool motorRunning = false;
  bool faultDetected = false;
  String faultMessage = "SYSTEM READY";
  float faultValue = 0;
  int wifiStrength = 0;
  unsigned long uptime = 0;
  int faultCount = 0;
  String ipAddress = "0.0.0.0";
} SystemData;

SystemData systemData;

// System state
bool wifiConnected = false;
bool gsmInitialized = false;
bool databaseAvailable = false;
unsigned long lastDatabaseSend = 0;
unsigned long systemStartTime = 0;
unsigned long lastDisplayScroll = 0;
unsigned long lastLedBlink = 0;
bool ledBlinkState = false;
int currentDisplayPage = 0;
#define PAGE_OVERVIEW    0
#define PAGE_CURRENTS    1
#define PAGE_STATUS      2
#define PAGE_SYSTEM      3
#define PAGE_COUNT       4

// Objects
OneWire oneWire(TEMP_SENSOR_PIN);
DallasTemperature tempSensors(&oneWire);

// ============================
// SETUP FUNCTION
// ============================
void setup() {
  // Initialize serial for debugging
  Serial.begin(115200);
  while (!Serial) {
    delay(10);
  }
  
  Serial.println(F("\n========================================="));
  Serial.println(F("MOTOR MONITORING SYSTEM - NANO IoT 33"));
  Serial.println(F("    20x4 LCD + LEDS VERSION"));
  Serial.println(F("========================================="));
  
  // Initialize I2C for LCD
  Wire.begin();
  
  // Initialize GSM Serial
  GSM_SERIAL.begin(9600);
  
  // Initialize system start time
  systemStartTime = millis();
  
  // Initialize LCD
  initializeLCD();
  
  // Initialize GPIO
  initializeGPIO();
  
  // Initialize sensors
  tempSensors.begin();
  emonVoltage.voltage(A0, VOLTAGE_CALIBRATION, PHASE_SHIFT);
  emonCurrent1.current(A1, CURRENT_CALIBRATION);
  emonCurrent2.current(A2, CURRENT_CALIBRATION);
  emonCurrent3.current(A3, CURRENT_CALIBRATION);
  
  // Initialize GSM
  initializeGSM();
  
  // Initialize WiFi
  initializeWiFi();
  
  // Welcome sequence
  welcomeSequence();
  
  Serial.println(F("SYSTEM READY"));
}

// ============================
// MAIN LOOP
// ============================
void loop() {
  unsigned long currentMillis = millis();
  
  // Update uptime
  systemData.uptime = (currentMillis - systemStartTime) / 1000;
  
  // Handle buttons
  handleButtons();
  
  // Update LED indicators
  updateLEDs(currentMillis);
  
  // Read sensors every 2 seconds
  static unsigned long lastSensorRead = 0;
  if (currentMillis - lastSensorRead >= SENSOR_READ_INTERVAL) {
    lastSensorRead = currentMillis;
    readSensors();
    checkFaults();
  }
  
  // Update display every second
  static unsigned long lastDisplayUpdate = 0;
  if (currentMillis - lastDisplayUpdate >= DISPLAY_UPDATE_INTERVAL) {
    lastDisplayUpdate = currentMillis;
    updateDisplay();
  }
  
  // Auto-scroll display pages
  if (currentMillis - lastDisplayScroll >= DISPLAY_SCROLL_INTERVAL) {
    lastDisplayScroll = currentMillis;
    currentDisplayPage = (currentDisplayPage + 1) % PAGE_COUNT;
  }
  
  // Send to database every 10 seconds if WiFi connected
  if (wifiConnected && currentMillis - lastDatabaseSend >= DATABASE_SEND_INTERVAL) {
    lastDatabaseSend = currentMillis;
    sendToDatabase();
  }
  
  // Small delay
  delay(10);
}

// ============================
// INITIALIZATION FUNCTIONS
// ============================
void initializeLCD() {
  lcd.init();
  lcd.backlight();
  
  // Show startup screen
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print(" MOTOR MONITORING");
  lcd.setCursor(0, 1);
  lcd.print("      SYSTEM");
  lcd.setCursor(0, 2);
  lcd.print("  20x4 LCD + LEDS");
  lcd.setCursor(0, 3);
  lcd.print("  Initializing...");
  
  delay(2000);
}

void initializeGPIO() {
  // Output pins
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(RED_LED_PIN, OUTPUT);
  pinMode(YELLOW_LED_PIN, OUTPUT);
  pinMode(GREEN_LED_PIN, OUTPUT);
  
  // Input pins
  pinMode(VIBRATION_PIN, INPUT);
  pinMode(START_BUTTON_PIN, INPUT_PULLUP);
  pinMode(STOP_BUTTON_PIN, INPUT_PULLUP);
  pinMode(RESET_BUTTON_PIN, INPUT_PULLUP);
  
  // Initial states
  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(RELAY_PIN, HIGH);  // Relay OFF (motor stopped)
  digitalWrite(RED_LED_PIN, LOW);
  digitalWrite(YELLOW_LED_PIN, LOW);
  digitalWrite(GREEN_LED_PIN, LOW);
}

void initializeWiFi() {
  Serial.println(F("\n=== INITIALIZING WiFi ==="));
  displayMessage("WiFi INIT", "Connecting...", "", "");
  
  // Check for WiFi module
  if (WiFi.status() == WL_NO_MODULE) {
    Serial.println(F("ERROR: No WiFi module found!"));
    displayMessage("ERROR", "No WiFi Module", "", "");
    digitalWrite(RED_LED_PIN, HIGH);  // Red LED for error
    return;
  }
  
  // Check firmware
  String fv = WiFi.firmwareVersion();
  Serial.print(F("WiFi Firmware: "));
  Serial.println(fv);
  
  if (fv < WIFI_FIRMWARE_LATEST_VERSION) {
    Serial.println(F("WARNING: Please upgrade WiFi firmware"));
  }
  
  // Attempt connection
  Serial.print(F("Connecting to: "));
  Serial.println(ssid);
  
  int attempts = 0;
  while (attempts < 5) {
    wifiStatus = WiFi.begin(ssid, pass);
    
    if (wifiStatus == WL_CONNECTED) {
      wifiConnected = true;
      systemData.ipAddress = getIpAddress();
      systemData.wifiStrength = WiFi.RSSI();
      
      Serial.println(F("WiFi CONNECTED!"));
      Serial.print(F("IP Address: "));
      Serial.println(systemData.ipAddress);
      Serial.print(F("Signal: "));
      Serial.print(systemData.wifiStrength);
      Serial.println(F(" dBm"));
      
      displayMessage("WiFi CONNECTED", "IP: " + systemData.ipAddress, "", "");
      beepBuzzer(1);
      delay(2000);
      return;
    }
    
    attempts++;
    Serial.print(F("Attempt "));
    Serial.print(attempts);
    Serial.println(F(" failed. Retrying..."));
    displayMessage("WiFi Attempt", String(attempts), "Failed...", "");
    delay(3000);
  }
  
  Serial.println(F("WiFi connection FAILED"));
  displayMessage("WiFi FAILED", "Check Credentials", "", "");
  digitalWrite(YELLOW_LED_PIN, HIGH);  // Yellow LED for warning
}

void initializeGSM() {
  Serial.println(F("\n=== INITIALIZING GSM ==="));
  displayMessage("GSM INIT", "Starting...", "", "");
  
  delay(2000);
  
  // Send AT commands
  sendGSMCommand("AT", 1000);
  sendGSMCommand("ATE0", 500);
  sendGSMCommand("AT+CMGF=1", 500);
  sendGSMCommand("AT+CSQ", 500);
  
  gsmInitialized = true;
  Serial.println(F("GSM Initialized"));
  displayMessage("GSM Ready", "", "", "");
}

void welcomeSequence() {
  // LED test sequence
  digitalWrite(RED_LED_PIN, HIGH);
  delay(300);
  digitalWrite(RED_LED_PIN, LOW);
  digitalWrite(YELLOW_LED_PIN, HIGH);
  delay(300);
  digitalWrite(YELLOW_LED_PIN, LOW);
  digitalWrite(GREEN_LED_PIN, HIGH);
  delay(300);
  digitalWrite(GREEN_LED_PIN, LOW);
  
  // Buzzer test
  beepBuzzer(2);
  
  // Final LED state
  digitalWrite(GREEN_LED_PIN, HIGH);  // System ready
}

// ============================
// HELPER FUNCTIONS
// ============================
void sendGSMCommand(String cmd, int delayTime) {
  GSM_SERIAL.println(cmd);
  delay(delayTime);
  
  Serial.print(F("GSM >> "));
  Serial.println(cmd);
  
  // Read response
  while (GSM_SERIAL.available()) {
    Serial.write(GSM_SERIAL.read());
  }
}

String getIpAddress() {
  IPAddress ip = WiFi.localIP();
  return String(ip[0]) + "." + ip[1] + "." + ip[2] + "." + ip[3];
}

void displayMessage(String line1, String line2, String line3, String line4) {
  lcd.clear();
  
  if (line1.length() > 0) {
    lcd.setCursor(0, 0);
    lcd.print(centerText(line1));
  }
  if (line2.length() > 0) {
    lcd.setCursor(0, 1);
    lcd.print(centerText(line2));
  }
  if (line3.length() > 0) {
    lcd.setCursor(0, 2);
    lcd.print(centerText(line3));
  }
  if (line4.length() > 0) {
    lcd.setCursor(0, 3);
    lcd.print(centerText(line4));
  }
}

String centerText(String text) {
  if (text.length() >= LCD_COLS) {
    return text.substring(0, LCD_COLS);
  }
  
  int spaces = (LCD_COLS - text.length()) / 2;
  String result = "";
  for (int i = 0; i < spaces; i++) {
    result += " ";
  }
  result += text;
  return result;
}

void beepBuzzer(int count) {
  for (int i = 0; i < count; i++) {
    digitalWrite(BUZZER_PIN, HIGH);
    delay(100);
    digitalWrite(BUZZER_PIN, LOW);
    if (i < count - 1) delay(100);
  }
}

void updateLEDs(unsigned long currentMillis) {
  static bool warningCondition = false;
  
  // Check for warning conditions (not critical faults)
  warningCondition = (systemData.temperature > TEMP_WARNING && systemData.temperature <= TEMP_MAX) ||
                    (systemData.voltage < (VOLTAGE_MIN + 10) || systemData.voltage > (VOLTAGE_MAX - 10));
  
  if (systemData.faultDetected) {
    // FAULT CONDITION: Red LED blinking
    if (currentMillis - lastLedBlink >= LED_BLINK_INTERVAL) {
      lastLedBlink = currentMillis;
      ledBlinkState = !ledBlinkState;
      digitalWrite(RED_LED_PIN, ledBlinkState);
      digitalWrite(YELLOW_LED_PIN, LOW);
      digitalWrite(GREEN_LED_PIN, LOW);
    }
  } else if (warningCondition) {
    // WARNING CONDITION: Yellow LED blinking
    if (currentMillis - lastLedBlink >= LED_BLINK_INTERVAL) {
      lastLedBlink = currentMillis;
      ledBlinkState = !ledBlinkState;
      digitalWrite(YELLOW_LED_PIN, ledBlinkState);
      digitalWrite(RED_LED_PIN, LOW);
      digitalWrite(GREEN_LED_PIN, LOW);
    }
  } else if (systemData.motorRunning) {
    // MOTOR RUNNING: Green LED steady
    digitalWrite(GREEN_LED_PIN, HIGH);
    digitalWrite(RED_LED_PIN, LOW);
    digitalWrite(YELLOW_LED_PIN, LOW);
    ledBlinkState = false;
  } else if (wifiConnected && databaseAvailable) {
    // SYSTEM IDLE, CONNECTED: Green LED steady
    digitalWrite(GREEN_LED_PIN, HIGH);
    digitalWrite(RED_LED_PIN, LOW);
    digitalWrite(YELLOW_LED_PIN, LOW);
    ledBlinkState = false;
  } else if (wifiConnected && !databaseAvailable) {
    // WIFI CONNECTED, DB OFFLINE: Yellow LED steady
    digitalWrite(YELLOW_LED_PIN, HIGH);
    digitalWrite(RED_LED_PIN, LOW);
    digitalWrite(GREEN_LED_PIN, LOW);
    ledBlinkState = false;
  } else {
    // NO WIFI: Red LED steady
    digitalWrite(RED_LED_PIN, HIGH);
    digitalWrite(YELLOW_LED_PIN, LOW);
    digitalWrite(GREEN_LED_PIN, LOW);
    ledBlinkState = false;
  }
}

// ============================
// SENSOR FUNCTIONS
// ============================
void readSensors() {
  // Read temperature
  tempSensors.requestTemperatures();
  systemData.temperature = tempSensors.getTempCByIndex(0);
  
  // Read vibration
  systemData.vibration = digitalRead(VIBRATION_PIN);
  
  // Read voltage and current
  emonVoltage.calcVI(20, 2000);
  systemData.voltage = emonVoltage.Vrms;
  
  systemData.currentL1 = emonCurrent1.calcIrms(1480);
  systemData.currentL2 = emonCurrent2.calcIrms(1480);
  systemData.currentL3 = emonCurrent3.calcIrms(1480);
  
  // Update WiFi signal if connected
  if (wifiConnected) {
    systemData.wifiStrength = WiFi.RSSI();
  }
  
  // Debug output
  Serial.print(F("Sensors: V="));
  Serial.print(systemData.voltage, 1);
  Serial.print(F("V, I1="));
  Serial.print(systemData.currentL1, 2);
  Serial.print(F("A, I2="));
  Serial.print(systemData.currentL2, 2);
  Serial.print(F("A, I3="));
  Serial.print(systemData.currentL3, 2);
  Serial.print(F("A, T="));
  Serial.print(systemData.temperature, 1);
  Serial.print(F("C, Vib="));
  Serial.println(systemData.vibration);
}

void checkFaults() {
  bool newFault = false;
  String faultMsg = "";
  float faultVal = 0;
  
  // Check all conditions
  if (systemData.voltage < VOLTAGE_MIN) {
    newFault = true;
    faultMsg = "UNDERVOLTAGE";
    faultVal = systemData.voltage;
  } else if (systemData.voltage > VOLTAGE_MAX) {
    newFault = true;
    faultMsg = "OVERVOLTAGE";
    faultVal = systemData.voltage;
  } else if (systemData.currentL1 > CURRENT_MAX) {
    newFault = true;
    faultMsg = "OVERCURRENT L1";
    faultVal = systemData.currentL1;
  } else if (systemData.currentL2 > CURRENT_MAX) {
    newFault = true;
    faultMsg = "OVERCURRENT L2";
    faultVal = systemData.currentL2;
  } else if (systemData.currentL3 > CURRENT_MAX) {
    newFault = true;
    faultMsg = "OVERCURRENT L3";
    faultVal = systemData.currentL3;
  } else if (systemData.temperature > TEMP_MAX) {
    newFault = true;
    faultMsg = "HIGH TEMP";
    faultVal = systemData.temperature;
  } else if (systemData.vibration == HIGH) {
    newFault = true;
    faultMsg = "VIBRATION";
    faultVal = 1.0;
  }
  
  // Handle fault
  if (newFault && !systemData.faultDetected) {
    systemData.faultDetected = true;
    systemData.faultMessage = faultMsg;
    systemData.faultValue = faultVal;
    systemData.faultCount++;
    
    // Safety: turn off motor
    digitalWrite(RELAY_PIN, HIGH);
    systemData.motorRunning = false;
    
    // Alert - Buzzer and LEDs
    for (int i = 0; i < 3; i++) {
      digitalWrite(BUZZER_PIN, HIGH);
      digitalWrite(RED_LED_PIN, HIGH);
      delay(300);
      digitalWrite(BUZZER_PIN, LOW);
      digitalWrite(RED_LED_PIN, LOW);
      delay(200);
    }
    
    // Send SMS
    sendSMSAlert(faultMsg, faultVal);
    
    Serial.print(F("FAULT: "));
    Serial.println(faultMsg);
    
    // Show fault on display
    displayMessage("!!! FAULT !!!", faultMsg, "Val: " + String(faultVal, 1), "Motor STOPPED");
    delay(3000);
  } else if (!newFault && systemData.faultDetected) {
    systemData.faultDetected = false;
    systemData.faultMessage = "SYSTEM NORMAL";
    beepBuzzer(1);  // Single beep for fault cleared
  }
}

// ============================
// BUTTON FUNCTIONS
// ============================
void handleButtons() {
  static unsigned long lastButtonTime = 0;
  unsigned long now = millis();
  
  // Debounce
  if (now - lastButtonTime < BUTTON_DEBOUNCE) return;
  
  // Start button - Motor START
  if (digitalRead(START_BUTTON_PIN) == LOW) {
    lastButtonTime = now;
    if (!systemData.faultDetected) {
      digitalWrite(RELAY_PIN, LOW);  // Relay ON (motor starts)
      systemData.motorRunning = true;
      beepBuzzer(1);
      Serial.println(F("Motor STARTED"));
      displayMessage("Motor STARTED", "Running...", "", "");
      delay(1000);
    } else {
      beepBuzzer(3);
      Serial.println(F("Cannot start - Fault detected"));
      displayMessage("CANNOT START", "Fault Detected:", systemData.faultMessage, "");
      delay(1000);
    }
  }
  
  // Stop button - Motor STOP
  if (digitalRead(STOP_BUTTON_PIN) == LOW) {
    lastButtonTime = now;
    digitalWrite(RELAY_PIN, HIGH);  // Relay OFF (motor stops)
    systemData.motorRunning = false;
    beepBuzzer(2);
    Serial.println(F("Motor STOPPED"));
    displayMessage("Motor STOPPED", "Manual Stop", "", "");
    delay(1000);
  }
  
  // Reset/Page button - Manual page change
  if (digitalRead(RESET_BUTTON_PIN) == LOW) {
    lastButtonTime = now;
    currentDisplayPage = (currentDisplayPage + 1) % PAGE_COUNT;
    lastDisplayScroll = now;  // Reset auto-scroll timer
    beepBuzzer(1);
    Serial.print(F("Manual page change to: "));
    Serial.println(currentDisplayPage);
    
    // Show page number briefly
    displayMessage("Page " + String(currentDisplayPage + 1), "of " + String(PAGE_COUNT), "", "");
    delay(800);
  }
}

// ============================
// DISPLAY FUNCTIONS
// ============================
void updateDisplay() {
  lcd.clear();
  
  switch (currentDisplayPage) {
    case PAGE_OVERVIEW:
      displayOverview();
      break;
    case PAGE_CURRENTS:
      displayCurrents();
      break;
    case PAGE_STATUS:
      displayStatus();
      break;
    case PAGE_SYSTEM:
      displaySystemInfo();
      break;
  }
}

void displayOverview() {
  // Line 1: Voltage and Temperature
  lcd.setCursor(0, 0);
  lcd.print("V:");
  lcd.print(systemData.voltage, 1);
  lcd.print("V ");
  
  // Show voltage status
  if (systemData.voltage < VOLTAGE_MIN || systemData.voltage > VOLTAGE_MAX) {
    lcd.print("!");
  } else {
    lcd.print(" ");
  }
  
  lcd.print(" T:");
  lcd.print(systemData.temperature, 1);
  lcd.print("C");
  
  if (systemData.temperature > TEMP_MAX) {
    lcd.print("!");
  } else if (systemData.temperature > TEMP_WARNING) {
    lcd.print("*");  // Warning indicator
  }
  
  // Line 2: Motor and Vibration status
  lcd.setCursor(0, 1);
  lcd.print("Motor: ");
  if (systemData.motorRunning) {
    lcd.print("RUN ");
  } else {
    lcd.print("STOP ");
  }
  
  lcd.print("Vib: ");
  if (systemData.vibration) {
    lcd.print("HI!");
  } else {
    lcd.print("OK ");
  }
  
  // Line 3: Fault status
  lcd.setCursor(0, 2);
  lcd.print("Fault: ");
  if (systemData.faultDetected) {
    lcd.print(systemData.faultMessage.substring(0, 13));
  } else {
    lcd.print("NONE");
  }
  
  // Line 4: Page indicator and uptime
  lcd.setCursor(0, 3);
  lcd.print("Pg:1/4 ");
  
  // Show uptime
  unsigned long hours = systemData.uptime / 3600;
  unsigned long minutes = (systemData.uptime % 3600) / 60;
  lcd.print("Up:");
  if (hours < 10) lcd.print("0");
  lcd.print(hours);
  lcd.print(":");
  if (minutes < 10) lcd.print("0");
  lcd.print(minutes);
  
  // Show LED status with symbols
  lcd.print(" ");
  if (systemData.faultDetected) {
    lcd.print("R");  // Red
  } else if (systemData.motorRunning) {
    lcd.print("G");  // Green
  } else {
    lcd.print("Y");  // Yellow
  }
}

void displayCurrents() {
  // Line 1: Header
  lcd.setCursor(0, 0);
  lcd.print("PHASE CURRENTS");
  
  // Line 2: L1 and L2
  lcd.setCursor(0, 1);
  lcd.print("L1:");
  lcd.print(systemData.currentL1, 2);
  lcd.print("A ");
  
  if (systemData.currentL1 > CURRENT_MAX) {
    lcd.print("!");
  } else {
    lcd.print(" ");
  }
  
  lcd.print("L2:");
  lcd.print(systemData.currentL2, 2);
  lcd.print("A");
  
  if (systemData.currentL2 > CURRENT_MAX) {
    lcd.print("!");
  }
  
  // Line 3: L3 and total
  lcd.setCursor(0, 2);
  lcd.print("L3:");
  lcd.print(systemData.currentL3, 2);
  lcd.print("A");
  
  if (systemData.currentL3 > CURRENT_MAX) {
    lcd.print("!");
  }
  
  // Calculate total current
  float totalCurrent = systemData.currentL1 + systemData.currentL2 + systemData.currentL3;
  lcd.print(" Tot:");
  lcd.print(totalCurrent, 1);
  lcd.print("A");
  
  // Line 4: Page indicator and max limit
  lcd.setCursor(0, 3);
  lcd.print("Pg:2/4 Max:");
  lcd.print(CURRENT_MAX);
  lcd.print("A");
  
  // Button indicators
  lcd.print(" S");
}

void displayStatus() {
  // Line 1: Header
  lcd.setCursor(0, 0);
  lcd.print("SYSTEM STATUS");
  
  // Line 2: WiFi status
  lcd.setCursor(0, 1);
  lcd.print("WiFi: ");
  if (wifiConnected) {
    lcd.print("ON ");
    lcd.print(systemData.wifiStrength);
    lcd.print("dBm");
  } else {
    lcd.print("OFF");
  }
  
  // Line 3: Database and GSM
  lcd.setCursor(0, 2);
  lcd.print("DB: ");
  lcd.print(databaseAvailable ? "OK" : "NO");
  lcd.print(" GSM: ");
  lcd.print(gsmInitialized ? "OK" : "NO");
  
  // Line 4: Fault count and Page indicator
  lcd.setCursor(0, 3);
  lcd.print("Faults:");
  lcd.print(systemData.faultCount);
  lcd.print(" Pg:3/4");
  
  // Button indicators
  lcd.print(" R");
}

void displaySystemInfo() {
  // Line 1: IP Address (first part)
  lcd.setCursor(0, 0);
  if (wifiConnected) {
    lcd.print("IP:");
    lcd.print(systemData.ipAddress.substring(0, 16));
  } else {
    lcd.print("No WiFi Connection");
  }
  
  // Line 2: Voltage details
  lcd.setCursor(0, 1);
  lcd.print("V:");
  lcd.print(systemData.voltage, 1);
  lcd.print("V (");
  lcd.print(VOLTAGE_MIN);
  lcd.print("-");
  lcd.print(VOLTAGE_MAX);
  lcd.print(")");
  
  // Line 3: Temperature details
  lcd.setCursor(0, 2);
  lcd.print("Temp:");
  lcd.print(systemData.temperature, 1);
  lcd.print("C Max:");
  lcd.print(TEMP_MAX);
  lcd.print("C");
  
  // Line 4: Page indicator and auto/manual
  lcd.setCursor(0, 3);
  lcd.print("Pg:4/4 Auto-scroll");
  
  // Button indicators
  lcd.print(" P");
}

// ============================
// DATABASE FUNCTIONS
// ============================
void sendToDatabase() {
  if (!wifiConnected) {
    Serial.println(F("Cannot send to DB: WiFi not connected"));
    return;
  }
  
  Serial.println(F("\n=== SENDING TO DATABASE ==="));
  
  // Prepare POST data
  String postData = "voltage=" + String(systemData.voltage, 2);
  postData += "&current1=" + String(systemData.currentL1, 2);
  postData += "&current2=" + String(systemData.currentL2, 2);
  postData += "&current3=" + String(systemData.currentL3, 2);
  postData += "&temperature=" + String(systemData.temperature, 1);
  postData += "&vibration=" + String(systemData.vibration);
  postData += "&motor_status=" + String(systemData.motorRunning ? "ON" : "OFF");
  postData += "&fault_status=" + String(systemData.faultDetected ? "1" : "0");
  postData += "&fault_message=" + systemData.faultMessage;
  postData += "&fault_value=" + String(systemData.faultValue, 2);
  postData += "&wifi_strength=" + String(systemData.wifiStrength);
  postData += "&uptime=" + String(systemData.uptime);
  
  Serial.print(F("POST Data: "));
  Serial.println(postData);
  Serial.print(F("URL: http://"));
  Serial.print(server);
  Serial.println(apiEndpoint);
  
  // Make HTTP POST request
  client.beginRequest();
  client.post(apiEndpoint);
  client.sendHeader("Content-Type", "application/x-www-form-urlencoded");
  client.sendHeader("Content-Length", postData.length());
  client.beginBody();
  client.print(postData);
  client.endRequest();
  
  // Get response
  int statusCode = client.responseStatusCode();
  String response = client.responseBody();
  
  Serial.print(F("Status Code: "));
  Serial.println(statusCode);
  Serial.print(F("Response: "));
  Serial.println(response);
  
  if (statusCode == 200) {
    databaseAvailable = true;
    Serial.println(F("Database update SUCCESS"));
  } else {
    databaseAvailable = false;
    Serial.print(F("Database update FAILED: "));
    Serial.println(statusCode);
    
    // Debug connection
    Serial.print(F("WiFi Status: "));
    Serial.println(WiFi.status());
    
    if (WiFi.status() != WL_CONNECTED) {
      Serial.println(F("WiFi disconnected. Attempting reconnect..."));
      initializeWiFi();
    }
  }
}

// ============================
// SMS FUNCTIONS
// ============================
void sendSMSAlert(String faultMsg, float value) {
  if (!gsmInitialized) {
    Serial.println(F("Cannot send SMS: GSM not initialized"));
    return;
  }
  
  Serial.println(F("\n=== SENDING SMS ALERT ==="));
  
  String message = "MOTOR ALERT!\n";
  message += "Fault: " + faultMsg + "\n";
  message += "Value: " + String(value, 1) + "\n";
  message += "Time: " + String(systemData.uptime / 3600) + "h ";
  message += String((systemData.uptime % 3600) / 60) + "m\n";
  message += "V: " + String(systemData.voltage, 1) + "V\n";
  message += "T: " + String(systemData.temperature, 1) + "C";
  
  Serial.println(message);
  
  // Send AT commands
  GSM_SERIAL.println("AT+CMGF=1");
  delay(1000);
  
  GSM_SERIAL.print("AT+CMGS=\"");
  GSM_SERIAL.print(PHONE_NUMBER);
  GSM_SERIAL.println("\"");
  delay(1000);
  
  GSM_SERIAL.print(message);
  delay(500);
  
  GSM_SERIAL.write(26); // CTRL+Z
  delay(3000);
  
  Serial.println(F("SMS sent (check GSM for confirmation)"));
}

// ============================
// END OF CODE
// ============================
<?php
/**
 * Motor Monitoring System - Web Dashboard
 * File: dashboard.php
 */

// Database configuration
$config = [
    'host' => 'localhost',
    'dbname' => 'motor_monitoring',
    'username' => 'root',
    'password' => ''
];

try {
    $dsn = "mysql:host={$config['host']};dbname={$config['dbname']};charset=utf8";
    $pdo = new PDO($dsn, $config['username'], $config['password']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get latest data
$stmt = $pdo->query("SELECT * FROM motor_data ORDER BY timestamp DESC LIMIT 1");
$latest = $stmt->fetch();

// Get 24-hour summary
$summaryStmt = $pdo->query("
    SELECT 
        COUNT(*) as readings,
        AVG(voltage) as avg_voltage,
        MAX(voltage) as max_voltage,
        MIN(voltage) as min_voltage,
        AVG(temperature) as avg_temp,
        MAX(temperature) as max_temp,
        SUM(fault_status) as faults
    FROM motor_data 
    WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
");
$summary = $summaryStmt->fetch();

// Get recent faults
$faultsStmt = $pdo->query("SELECT * FROM fault_history ORDER BY timestamp DESC LIMIT 10");
$faults = $faultsStmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Motor Monitoring Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            transition: transform 0.3s;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .status-card {
            border-left: 5px solid;
        }
        .status-normal {
            border-left-color: #28a745;
        }
        .status-warning {
            border-left-color: #ffc107;
        }
        .status-alert {
            border-left-color: #dc3545;
        }
        .value-display {
            font-size: 2.5rem;
            font-weight: bold;
            text-align: center;
        }
        .unit {
            font-size: 1rem;
            color: #6c757d;
        }
        .last-updated {
            font-size: 0.8rem;
            color: #6c757d;
            text-align: right;
        }
        .nav-tabs .nav-link.active {
            font-weight: bold;
            background-color: #f8f9fa;
        }
        .chart-container {
            position: relative;
            height: 300px;
            width: 100%;
        }
    </style>
</head>
<body>
    <div class="container-fluid py-4">
        <!-- Header -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center">
                    <h1><i class="fas fa-industry"></i> Motor Monitoring Dashboard</h1>
                    <div class="last-updated">
                        <?php if ($latest): ?>
                            Last updated: <?= date('H:i:s', strtotime($latest['timestamp'])) ?>
                        <?php endif; ?>
                    </div>
                </div>
                <hr>
            </div>
        </div>

        <!-- Real-time Status Cards -->
        <div class="row mb-4">
            <!-- Voltage Card -->
            <div class="col-md-3 col-sm-6">
                <div class="card status-card <?= 
                    (!$latest || $latest['voltage'] < 180) ? 'status-alert' : 
                    ($latest['voltage'] > 250 ? 'status-warning' : 'status-normal') 
                ?>">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-bolt"></i> Voltage</h5>
                        <div class="value-display">
                            <?= $latest['voltage'] ?? 'N/A' ?> <span class="unit">V</span>
                        </div>
                        <p class="card-text">
                            Min: <?= number_format($summary['min_voltage'] ?? 0, 1) ?>V | 
                            Max: <?= number_format($summary['max_voltage'] ?? 0, 1) ?>V
                        </p>
                    </div>
                </div>
            </div>

            <!-- Temperature Card -->
            <div class="col-md-3 col-sm-6">
                <div class="card status-card <?= 
                    (!$latest || $latest['temperature'] > 30) ? 'status-warning' : 'status-normal' 
                ?>">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-thermometer-half"></i> Temperature</h5>
                        <div class="value-display">
                            <?= $latest['temperature'] ?? 'N/A' ?> <span class="unit">°C</span>
                        </div>
                        <p class="card-text">
                            Avg: <?= number_format($summary['avg_temp'] ?? 0, 1) ?>°C
                        </p>
                    </div>
                </div>
            </div>

            <!-- Current Card -->
            <div class="col-md-3 col-sm-6">
                <div class="card status-card <?= 
                    (!$latest || $latest['current1'] > 25 || $latest['current2'] > 25 || $latest['current3'] > 25) ? 
                    'status-warning' : 'status-normal' 
                ?>">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-tachometer-alt"></i> Current</h5>
                        <div class="row">
                            <div class="col-4 text-center">
                                <div>L1</div>
                                <div class="fw-bold"><?= $latest['current1'] ?? '0.0' ?>A</div>
                            </div>
                            <div class="col-4 text-center">
                                <div>L2</div>
                                <div class="fw-bold"><?= $latest['current2'] ?? '0.0' ?>A</div>
                            </div>
                            <div class="col-4 text-center">
                                <div>L3</div>
                                <div class="fw-bold"><?= $latest['current3'] ?? '0.0' ?>A</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- System Status Card -->
            <div class="col-md-3 col-sm-6">
                <div class="card status-card <?= 
                    (!$latest || $latest['fault_status'] == 1) ? 'status-alert' : 'status-normal' 
                ?>">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-cogs"></i> System Status</h5>
                        <div class="row">
                            <div class="col-6">
                                <div>Motor</div>
                                <div class="fw-bold"><?= $latest['motor_status'] ?? 'OFF' ?></div>
                            </div>
                            <div class="col-6">
                                <div>Faults</div>
                                <div class="fw-bold"><?= $summary['faults'] ?? 0 ?> today</div>
                            </div>
                        </div>
                        <div class="mt-2">
                            <div>WiFi Signal</div>
                            <div class="fw-bold"><?= $latest['wifi_strength'] ?? 0 ?> dBm</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Charts and Data Tabs -->
        <div class="row">
            <div class="col-12">
                <nav>
                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                        <button class="nav-link active" id="nav-charts-tab" data-bs-toggle="tab" data-bs-target="#nav-charts" type="button">Charts</button>
                        <button class="nav-link" id="nav-data-tab" data-bs-toggle="tab" data-bs-target="#nav-data" type="button">Live Data</button>
                        <button class="nav-link" id="nav-faults-tab" data-bs-toggle="tab" data-bs-target="#nav-faults" type="button">Fault History</button>
                    </div>
                </nav>
                <div class="tab-content p-3 border border-top-0 rounded-bottom" id="nav-tabContent">
                    <!-- Charts Tab -->
                    <div class="tab-pane fade show active" id="nav-charts" role="tabpanel">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Voltage Trend (Last 100 Readings)</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="chart-container">
                                            <canvas id="voltageChart"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Temperature Trend (Last 100 Readings)</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="chart-container">
                                            <canvas id="tempChart"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Live Data Tab -->
                    <div class="tab-pane fade" id="nav-data" role="tabpanel">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>Voltage (V)</th>
                                        <th>Current L1 (A)</th>
                                        <th>Current L2 (A)</th>
                                        <th>Current L3 (A)</th>
                                        <th>Temp (°C)</th>
                                        <th>Vibration</th>
                                        <th>Motor</th>
                                        <th>Fault</th>
                                    </tr>
                                </thead>
                                <tbody id="liveDataBody">
                                    <!-- Data will be loaded via JavaScript -->
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Fault History Tab -->
                    <div class="tab-pane fade" id="nav-faults" role="tabpanel">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>Fault Type</th>
                                        <th>Value</th>
                                        <th>Voltage (V)</th>
                                        <th>Temp (°C)</th>
                                        <th>Motor Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($faults as $fault): ?>
                                    <tr>
                                        <td><?= date('H:i:s', strtotime($fault['timestamp'])) ?></td>
                                        <td><span class="badge bg-danger"><?= htmlspecialchars($fault['fault_type']) ?></span></td>
                                        <td><?= $fault['fault_value'] ?></td>
                                        <td><?= $fault['voltage'] ?></td>
                                        <td><?= $fault['temperature'] ?></td>
                                        <td><?= $fault['motor_status'] ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Summary Statistics -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-chart-bar"></i> 24-Hour Summary</h5>
                    </div>
                    <div class="card-body">
                        <div class="row text-center">
                            <div class="col-md-2 col-sm-4">
                                <div class="display-6"><?= $summary['readings'] ?? 0 ?></div>
                                <div class="text-muted">Readings</div>
                            </div>
                            <div class="col-md-2 col-sm-4">
                                <div class="display-6"><?= number_format($summary['avg_voltage'] ?? 0, 1) ?></div>
                                <div class="text-muted">Avg Voltage (V)</div>
                            </div>
                            <div class="col-md-2 col-sm-4">
                                <div class="display-6"><?= number_format($summary['avg_temp'] ?? 0, 1) ?></div>
                                <div class="text-muted">Avg Temp (°C)</div>
                            </div>
                            <div class="col-md-2 col-sm-4">
                                <div class="display-6"><?= $summary['faults'] ?? 0 ?></div>
                                <div class="text-muted">Faults</div>
                            </div>
                            <div class="col-md-2 col-sm-4">
                                <?php
                                $motorOnTime = $summary['motor_on_time'] ?? 0;
                                $totalReadings = $summary['readings'] ?? 1;
                                $onPercentage = ($motorOnTime / $totalReadings) * 100;
                                ?>
                                <div class="display-6"><?= number_format($onPercentage, 1) ?>%</div>
                                <div class="text-muted">Motor ON Time</div>
                            </div>
                            <div class="col-md-2 col-sm-4">
                                <div class="display-6">
                                    <?php
                                    $uptime = $latest['uptime'] ?? 0;
                                    echo floor($uptime / 3600) . 'h ' . floor(($uptime % 3600) / 60) . 'm';
                                    ?>
                                </div>
                                <div class="text-muted">System Uptime</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
    <script>
        // Auto-refresh every 5 seconds
        setInterval(updateDashboard, 5000);

        // Initialize charts
        let voltageChart, tempChart;

        $(document).ready(function() {
            initCharts();
            updateDashboard();
            loadLiveData();
        });

        function initCharts() {
            const voltageCtx = document.getElementById('voltageChart').getContext('2d');
            voltageChart = new Chart(voltageCtx, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [{
                        label: 'Voltage (V)',
                        data: [],
                        borderColor: 'rgb(255, 99, 132)',
                        backgroundColor: 'rgba(255, 99, 132, 0.2)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: false,
                            suggestedMin: 180,
                            suggestedMax: 250
                        }
                    }
                }
            });

            const tempCtx = document.getElementById('tempChart').getContext('2d');
            tempChart = new Chart(tempCtx, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [{
                        label: 'Temperature (°C)',
                        data: [],
                        borderColor: 'rgb(54, 162, 235)',
                        backgroundColor: 'rgba(54, 162, 235, 0.2)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: false,
                            suggestedMin: 20,
                            suggestedMax: 35
                        }
                    }
                }
            });
        }

        function updateDashboard() {
            $.ajax({
                url: 'api.php?action=chart',
                method: 'GET',
                success: function(response) {
                    if (response.success && response.data.length > 0) {
                        updateCharts(response.data);
                    }
                }
            });
        }

        function updateCharts(data) {
            const labels = data.map(item => {
                const date = new Date(item.timestamp);
                return date.getHours() + ':' + date.getMinutes();
            });

            const voltages = data.map(item => item.voltage);
            const temperatures = data.map(item => item.temperature);

            voltageChart.data.labels = labels;
            voltageChart.data.datasets[0].data = voltages;

            tempChart.data.labels = labels;
            tempChart.data.datasets[0].data = temperatures;

            voltageChart.update('none');
            tempChart.update('none');
        }

        function loadLiveData() {
            $.ajax({
                url: 'api.php?action=latest&limit=20',
                method: 'GET',
                success: function(response) {
                    if (response.success) {
                        updateLiveDataTable(response.data);
                    }
                }
            });
        }

        function updateLiveDataTable(data) {
            let html = '';
            data.forEach(item => {
                const time = new Date(item.timestamp);
                const timeStr = time.getHours().toString().padStart(2, '0') + ':' + 
                               time.getMinutes().toString().padStart(2, '0') + ':' + 
                               time.getSeconds().toString().padStart(2, '0');
                
                html += `
                    <tr>
                        <td>${timeStr}</td>
                        <td>${item.voltage}</td>
                        <td>${item.current1}</td>
                        <td>${item.current2}</td>
                        <td>${item.current3}</td>
                        <td>${item.temperature}</td>
                        <td>${item.vibration ? 'HIGH' : 'NORMAL'}</td>
                        <td><span class="badge ${item.motor_status === 'ON' ? 'bg-success' : 'bg-secondary'}">${item.motor_status}</span></td>
                        <td>${item.fault_status ? '<span class="badge bg-danger">FAULT</span>' : '<span class="badge bg-success">OK</span>'}</td>
                    </tr>
                `;
            });
            $('#liveDataBody').html(html);
        }
    </script>
</body>
</html>
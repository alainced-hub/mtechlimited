<?php
/**
 * Motor Monitoring API - SIMPLIFIED VERSION
 * File: api.php
 * Location: C:\xampp\htdocs\motor_monitor\
 */

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set headers
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database configuration
$config = [
    'host' => 'localhost',
    'dbname' => 'motor_monitoring',
    'username' => 'root',
    'password' => ''  // Default XAMPP is empty
];

// Response array
$response = [
    'success' => false,
    'message' => '',
    'data' => []
];

try {
    // Create database connection
    $dsn = "mysql:host={$config['host']};dbname={$config['dbname']};charset=utf8";
    $pdo = new PDO($dsn, $config['username'], $config['password']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create table if it doesn't exist
    $createTableSQL = "
    CREATE TABLE IF NOT EXISTS motor_data (
        id INT AUTO_INCREMENT PRIMARY KEY,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        voltage DECIMAL(5,2),
        current1 DECIMAL(5,2),
        current2 DECIMAL(5,2),
        current3 DECIMAL(5,2),
        temperature DECIMAL(4,1),
        vibration TINYINT,
        motor_status VARCHAR(3),
        fault_status TINYINT,
        fault_message VARCHAR(100),
        fault_value DECIMAL(6,2),
        wifi_strength INT,
        uptime INT
    )";
    $pdo->exec($createTableSQL);
    
    // Handle POST request from Arduino
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        
        // Get POST data (from Arduino)
        $postData = file_get_contents("php://input");
        parse_str($postData, $data);
        
        // If parse_str didn't work, try $_POST
        if (empty($data)) {
            $data = $_POST;
        }
        
        // Log received data for debugging
        file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - " . print_r($data, true) . "\n", FILE_APPEND);
        
        // Validate required fields
        if (!isset($data['voltage'])) {
            throw new Exception("Missing voltage data");
        }
        
        // Prepare SQL statement
        $sql = "
            INSERT INTO motor_data 
            (voltage, current1, current2, current3, temperature, vibration, 
             motor_status, fault_status, fault_message, fault_value, wifi_strength, uptime)
            VALUES 
            (:voltage, :current1, :current2, :current3, :temperature, :vibration,
             :motor_status, :fault_status, :fault_message, :fault_value, :wifi_strength, :uptime)
        ";
        
        $stmt = $pdo->prepare($sql);
        
        // Bind parameters
        $params = [
            ':voltage' => floatval($data['voltage'] ?? 0),
            ':current1' => floatval($data['current1'] ?? 0),
            ':current2' => floatval($data['current2'] ?? 0),
            ':current3' => floatval($data['current3'] ?? 0),
            ':temperature' => floatval($data['temperature'] ?? 0),
            ':vibration' => intval($data['vibration'] ?? 0),
            ':motor_status' => $data['motor_status'] ?? 'OFF',
            ':fault_status' => intval($data['fault_status'] ?? 0),
            ':fault_message' => substr($data['fault_message'] ?? 'Normal', 0, 100),
            ':fault_value' => floatval($data['fault_value'] ?? 0),
            ':wifi_strength' => intval($data['wifi_strength'] ?? 0),
            ':uptime' => intval($data['uptime'] ?? 0)
        ];
        
        // Execute
        $stmt->execute($params);
        
        $response['success'] = true;
        $response['message'] = 'Data saved successfully';
        $response['data']['id'] = $pdo->lastInsertId();
        $response['data']['timestamp'] = date('Y-m-d H:i:s');
        
        http_response_code(201);
        
    } else {
        // Handle GET requests (for testing)
        $response['success'] = true;
        $response['message'] = 'API is working';
        $response['data']['status'] = 'online';
        $response['data']['time'] = date('Y-m-d H:i:s');
    }
    
} catch (PDOException $e) {
    $response['message'] = 'Database error: ' . $e->getMessage();
    http_response_code(500);
} catch (Exception $e) {
    $response['message'] = 'Error: ' . $e->getMessage();
    http_response_code(400);
}

// Output response
echo json_encode($response, JSON_PRETTY_PRINT);
?>
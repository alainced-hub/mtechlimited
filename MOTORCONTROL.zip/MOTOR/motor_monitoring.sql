-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 30, 2026 at 01:25 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `motor_monitoring`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `daily_summary`
-- (See below for the actual view)
--
CREATE TABLE `daily_summary` (
`date` date
,`total_readings` bigint(21)
,`avg_voltage` decimal(9,6)
,`max_voltage` decimal(5,2)
,`min_voltage` decimal(5,2)
,`avg_temp` decimal(8,5)
,`max_temp` decimal(4,1)
,`fault_count` decimal(25,0)
,`motor_on_count` decimal(22,0)
);

-- --------------------------------------------------------

--
-- Table structure for table `fault_history`
--

CREATE TABLE `fault_history` (
  `id` int(11) NOT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `fault_type` varchar(50) DEFAULT NULL,
  `fault_value` decimal(6,2) DEFAULT NULL,
  `voltage` decimal(5,2) DEFAULT NULL,
  `temperature` decimal(4,1) DEFAULT NULL,
  `current1` decimal(5,2) DEFAULT NULL,
  `current2` decimal(5,2) DEFAULT NULL,
  `current3` decimal(5,2) DEFAULT NULL,
  `motor_status` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `motor_data`
--

CREATE TABLE `motor_data` (
  `id` int(11) NOT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `voltage` decimal(5,2) DEFAULT NULL,
  `current1` decimal(5,2) DEFAULT NULL,
  `current2` decimal(5,2) DEFAULT NULL,
  `current3` decimal(5,2) DEFAULT NULL,
  `temperature` decimal(4,1) DEFAULT NULL,
  `vibration` tinyint(4) DEFAULT NULL,
  `motor_status` varchar(3) DEFAULT NULL,
  `fault_status` tinyint(4) DEFAULT NULL,
  `fault_message` varchar(100) DEFAULT NULL,
  `fault_value` decimal(6,2) DEFAULT NULL,
  `wifi_strength` int(11) DEFAULT NULL,
  `uptime` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `motor_data`
--

INSERT INTO `motor_data` (`id`, `timestamp`, `voltage`, `current1`, `current2`, `current3`, `temperature`, `vibration`, `motor_status`, `fault_status`, `fault_message`, `fault_value`, `wifi_strength`, `uptime`) VALUES
(501, '2026-01-28 14:36:41', 521.95, 2.22, 2.22, 3.81, -127.0, 0, 'OFF', 1, 'OVERVOLTAGE', 621.98, -46, 219),
(502, '2026-01-28 14:36:55', 324.07, 0.12, 0.12, 1.47, -127.0, 0, 'OFF', 1, 'OVERVOLTAGE', 621.98, -46, 234),
(503, '2026-01-28 14:37:10', 251.34, 0.01, 0.01, 1.37, -127.0, 0, 'OFF', 1, 'OVERVOLTAGE', 621.98, -46, 248),
(504, '2026-01-28 14:37:24', 203.95, 0.00, 0.00, 1.51, -127.0, 0, 'OFF', 0, 'SYSTEM NORMAL', 621.98, -45, 262),
(505, '2026-01-28 14:39:24', 606.45, 40.10, 40.10, 65.27, -127.0, 0, 'OFF', 1, 'OVERVOLTAGE', 606.45, -51, 13),
(506, '2026-01-28 14:39:32', 470.52, 9.44, 9.44, 15.43, -127.0, 0, 'OFF', 1, 'OVERVOLTAGE', 606.45, -49, 31),
(507, '2026-01-28 19:11:29', 619.91, 40.10, 40.10, 65.37, -127.0, 1, 'OFF', 1, 'OVERVOLTAGE', 619.91, -41, 16),
(508, '2026-01-28 19:11:36', 567.32, 9.44, 9.44, 15.49, -127.0, 0, 'OFF', 1, 'OVERVOLTAGE', 619.91, -41, 34),
(509, '2026-01-28 19:49:43', 502.81, 40.10, 40.10, 52.35, -127.0, 1, 'OFF', 1, 'OVERVOLTAGE', 502.81, -42, 13),
(510, '2026-01-28 19:49:51', 391.28, 9.44, 9.44, 16.70, -127.0, 0, 'OFF', 1, 'OVERVOLTAGE', 502.81, -32, 31),
(511, '2026-01-28 19:50:05', 256.14, 0.52, 0.52, 4.39, -127.0, 0, 'OFF', 1, 'OVERVOLTAGE', 502.81, -38, 46),
(512, '2026-01-28 19:50:19', 220.92, 0.03, 0.03, 3.96, -127.0, 1, 'OFF', 1, 'OVERVOLTAGE', 502.81, -42, 60),
(513, '2026-01-28 19:51:21', 186.61, 0.00, 0.00, 3.54, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -34, 75),
(514, '2026-01-28 19:51:37', 175.12, 0.00, 0.00, 2.71, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -46, 129),
(515, '2026-01-28 19:51:54', 162.02, 0.00, 0.00, 2.58, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -49, 145),
(516, '2026-01-28 19:52:02', 116.62, 0.00, 0.00, 2.55, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -53, 161),
(517, '2026-01-28 19:52:16', 69.57, 0.00, 0.00, 2.55, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -54, 176),
(518, '2026-01-28 19:52:30', 54.42, 0.00, 0.00, 2.52, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -58, 190),
(519, '2026-01-28 19:52:44', 48.10, 0.00, 0.00, 2.59, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -42, 204),
(520, '2026-01-28 19:52:58', 39.00, 0.00, 0.00, 2.33, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -47, 219),
(521, '2026-01-28 19:53:18', 31.27, 0.00, 0.00, 2.49, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -38, 233),
(522, '2026-01-28 19:53:26', 30.34, 0.00, 0.00, 3.35, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -32, 246),
(523, '2026-01-28 19:53:40', 27.36, 0.00, 0.00, 2.84, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -43, 260),
(524, '2026-01-28 19:53:54', 28.58, 0.00, 0.00, 2.79, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -38, 274),
(525, '2026-01-28 19:54:08', 28.11, 0.00, 0.00, 3.02, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -44, 288),
(526, '2026-01-28 19:54:22', 23.69, 0.00, 0.00, 2.63, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -46, 302),
(527, '2026-01-28 19:54:36', 23.49, 0.00, 0.00, 2.84, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -28, 316),
(528, '2026-01-28 19:54:50', 19.64, 0.00, 0.00, 2.45, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -29, 330),
(529, '2026-01-28 19:55:04', 22.02, 0.00, 0.00, 2.91, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -30, 344),
(530, '2026-01-28 19:55:27', 22.01, 0.00, 0.00, 2.76, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -29, 359),
(531, '2026-01-28 19:55:37', 23.22, 0.00, 0.00, 2.99, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -25, 375),
(532, '2026-01-28 19:55:54', 24.10, 0.00, 0.00, 2.86, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -27, 391),
(533, '2026-01-28 19:56:18', 20.97, 0.00, 0.00, 2.91, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -22, 402),
(534, '2026-01-28 19:56:25', 23.88, 0.00, 0.00, 2.77, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -44, 426),
(535, '2026-01-28 19:56:40', 29.70, 0.00, 0.00, 3.24, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -37, 440),
(536, '2026-01-28 19:56:54', 27.30, 0.00, 0.00, 3.04, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -58, 455),
(537, '2026-01-28 19:57:08', 22.32, 0.00, 0.00, 2.71, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -39, 469),
(538, '2026-01-28 19:57:22', 22.36, 0.00, 0.00, 2.63, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -37, 483),
(539, '2026-01-28 19:57:36', 21.17, 0.00, 0.00, 2.63, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -38, 497),
(540, '2026-01-28 19:57:50', 22.51, 0.00, 0.00, 2.88, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -41, 511),
(541, '2026-01-28 19:58:04', 23.78, 0.00, 0.00, 2.86, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -33, 525),
(542, '2026-01-28 19:58:18', 19.94, 0.00, 0.00, 2.84, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -30, 539),
(543, '2026-01-28 19:58:35', 22.12, 0.00, 0.00, 2.83, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -13, 553),
(544, '2026-01-28 19:58:52', 24.14, 0.00, 0.00, 2.73, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -15, 569),
(545, '2026-01-28 19:58:59', 23.89, 0.00, 0.00, 2.94, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -33, 580),
(546, '2026-01-28 19:59:13', 22.99, 0.00, 0.00, 2.95, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -30, 594),
(547, '2026-01-28 19:59:28', 21.52, 0.00, 0.00, 2.94, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -29, 608),
(548, '2026-01-28 19:59:42', 22.56, 0.00, 0.00, 2.94, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -34, 622),
(549, '2026-01-28 19:59:56', 24.36, 0.00, 0.00, 3.25, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -32, 636),
(550, '2026-01-28 20:00:10', 24.82, 0.00, 0.00, 2.94, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -34, 650),
(551, '2026-01-28 20:00:24', 22.81, 0.00, 0.00, 2.74, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -38, 665),
(552, '2026-01-28 20:00:38', 21.13, 0.00, 0.00, 2.77, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -33, 679),
(553, '2026-01-28 20:00:52', 22.63, 0.00, 0.00, 2.80, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -34, 693),
(554, '2026-01-28 20:01:06', 23.03, 0.00, 0.00, 2.93, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -34, 707),
(555, '2026-01-28 20:01:20', 23.95, 0.00, 0.00, 3.05, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -38, 721),
(556, '2026-01-28 20:01:34', 23.35, 0.00, 0.00, 3.12, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -33, 735),
(557, '2026-01-28 20:01:48', 25.49, 0.00, 0.00, 3.07, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -49, 749),
(558, '2026-01-28 20:02:03', 25.74, 0.00, 0.00, 3.09, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -51, 763),
(559, '2026-01-28 20:02:17', 26.33, 0.00, 0.00, 3.15, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -45, 778),
(560, '2026-01-28 20:02:33', 25.47, 0.00, 0.00, 3.19, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -33, 792),
(561, '2026-01-28 20:02:49', 22.36, 0.00, 0.00, 2.75, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -43, 808),
(562, '2026-01-28 20:03:05', 20.45, 0.00, 0.00, 2.75, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -47, 824),
(563, '2026-01-28 20:03:19', 21.08, 0.00, 0.00, 2.86, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -35, 840),
(564, '2026-01-28 20:03:33', 22.71, 0.00, 0.00, 2.71, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -39, 854),
(565, '2026-01-28 20:03:47', 22.57, 0.00, 0.00, 2.75, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -41, 868),
(566, '2026-01-28 20:04:01', 23.04, 0.00, 0.00, 2.85, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -37, 882),
(567, '2026-01-28 20:04:15', 22.31, 0.00, 0.00, 2.75, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -42, 896),
(568, '2026-01-28 20:04:29', 20.61, 0.00, 0.00, 2.57, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -39, 910),
(569, '2026-01-28 20:04:44', 21.43, 0.00, 0.00, 2.63, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -39, 924),
(570, '2026-01-28 20:04:58', 21.83, 0.00, 0.00, 2.56, -127.0, 0, 'OFF', 1, 'VIBRATION', 1.00, -40, 938),
(571, '2026-01-28 20:05:12', 20.38, 0.00, 0.00, 2.49, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -38, 952),
(572, '2026-01-28 20:05:26', 22.87, 0.00, 0.00, 2.71, -127.0, 1, 'OFF', 1, 'VIBRATION', 1.00, -44, 966);

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL,
  `setting_name` varchar(50) DEFAULT NULL,
  `setting_value` varchar(100) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `setting_name`, `setting_value`, `updated_at`) VALUES
(1, 'voltage_min', '180', '2026-01-08 08:16:14'),
(2, 'voltage_max', '250', '2026-01-08 08:16:14'),
(3, 'current_max', '25', '2026-01-08 08:16:14'),
(4, 'temp_max', '30', '2026-01-08 08:16:14'),
(5, 'sms_enabled', '1', '2026-01-08 08:16:14'),
(6, 'alert_phone', '+250788708035', '2026-01-08 08:16:14');

-- --------------------------------------------------------

--
-- Structure for view `daily_summary`
--
DROP TABLE IF EXISTS `daily_summary`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `daily_summary`  AS SELECT cast(`motor_data`.`timestamp` as date) AS `date`, count(0) AS `total_readings`, avg(`motor_data`.`voltage`) AS `avg_voltage`, max(`motor_data`.`voltage`) AS `max_voltage`, min(`motor_data`.`voltage`) AS `min_voltage`, avg(`motor_data`.`temperature`) AS `avg_temp`, max(`motor_data`.`temperature`) AS `max_temp`, sum(`motor_data`.`fault_status`) AS `fault_count`, sum(case when `motor_data`.`motor_status` = 'ON' then 1 else 0 end) AS `motor_on_count` FROM `motor_data` GROUP BY cast(`motor_data`.`timestamp` as date) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fault_history`
--
ALTER TABLE `fault_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_fault_timestamp` (`timestamp`);

--
-- Indexes for table `motor_data`
--
ALTER TABLE `motor_data`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_timestamp` (`timestamp`),
  ADD KEY `idx_fault_status` (`fault_status`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting_name` (`setting_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fault_history`
--
ALTER TABLE `fault_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `motor_data`
--
ALTER TABLE `motor_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=573;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

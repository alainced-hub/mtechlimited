<?php
// test.php - Place in C:\xampp\htdocs\motor_monitor\
?>
<!DOCTYPE html>
<html>
<head>
    <title>Database Test</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        .success { color: green; }
        .error { color: red; }
        .form { margin: 20px 0; padding: 20px; border: 1px solid #ccc; }
        input, button { margin: 5px; padding: 8px; }
    </style>
</head>
<body>
    <h1>Motor Monitoring - Database Test</h1>
    
    <div class="form">
        <h3>1. Test Database Connection</h3>
        <?php
        try {
            $pdo = new PDO('mysql:host=localhost;dbname=motor_monitoring', 'root', '');
            echo "<p class='success'>✓ Database connection successful!</p>";
            
            // Check if table exists
            $tables = $pdo->query("SHOW TABLES LIKE 'motor_data'")->fetch();
            if ($tables) {
                echo "<p class='success'>✓ Table 'motor_data' exists</p>";
                
                // Count records
                $count = $pdo->query("SELECT COUNT(*) FROM motor_data")->fetchColumn();
                echo "<p>Records in table: " . $count . "</p>";
                
                // Show recent records
                if ($count > 0) {
                    echo "<h4>Recent Data:</h4>";
                    $stmt = $pdo->query("SELECT * FROM motor_data ORDER BY timestamp DESC LIMIT 5");
                    echo "<table border='1' cellpadding='5'>";
                    echo "<tr><th>Time</th><th>Voltage</th><th>Temp</th><th>Motor</th><th>Fault</th></tr>";
                    while ($row = $stmt->fetch()) {
                        echo "<tr>";
                        echo "<td>" . $row['timestamp'] . "</td>";
                        echo "<td>" . $row['voltage'] . "V</td>";
                        echo "<td>" . $row['temperature'] . "°C</td>";
                        echo "<td>" . $row['motor_status'] . "</td>";
                        echo "<td>" . ($row['fault_status'] ? 'YES' : 'NO') . "</td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                }
            } else {
                echo "<p class='error'>✗ Table 'motor_data' doesn't exist</p>";
            }
            
        } catch (PDOException $e) {
            echo "<p class='error'>✗ Database error: " . $e->getMessage() . "</p>";
        }
        ?>
    </div>
    
    <div class="form">
        <h3>2. Test API Endpoint</h3>
        <button onclick="testAPI()">Test API Connection</button>
        <div id="apiResult"></div>
    </div>
    
    <div class="form">
        <h3>3. Test Your Arduino IP</h3>
        <p>Your computer's IP: <strong><?php echo $_SERVER['SERVER_ADDR']; ?></strong></p>
        <p>Access this page from Arduino's network: http://<?php echo $_SERVER['SERVER_ADDR']; ?>/motor_monitor/test.php</p>
    </div>
    
    <div class="form">
        <h3>4. Manual Test Data</h3>
        <form id="testForm">
            Voltage: <input type="text" name="voltage" value="220.5"><br>
            Temperature: <input type="text" name="temperature" value="25.5"><br>
            <button type="button" onclick="sendTestData()">Send Test Data</button>
        </form>
        <div id="testResult"></div>
    </div>
    
    <script>
    function testAPI() {
        fetch('api.php')
            .then(response => response.json())
            .then(data => {
                document.getElementById('apiResult').innerHTML = 
                    `<p class='success'>✓ API Response: ${data.message}</p>`;
            })
            .catch(error => {
                document.getElementById('apiResult').innerHTML = 
                    `<p class='error'>✗ API Error: ${error}</p>`;
            });
    }
    
    function sendTestData() {
        const form = document.getElementById('testForm');
        const formData = new FormData(form);
        
        fetch('api.php', {
            method: 'POST',
            body: new URLSearchParams(formData)
        })
        .then(response => response.json())
        .then(data => {
            document.getElementById('testResult').innerHTML = 
                `<p class='success'>✓ ${data.message}</p>`;
        })
        .catch(error => {
            document.getElementById('testResult').innerHTML = 
                `<p class='error'>✗ Error: ${error}</p>`;
        });
    }
    </script>
</body>
</html>